package Calulator;

public class CalClass {
	
	public int add(int a,int b) {
		return a+b;
	}
	public int mul(int a,int b) {
		return a*b;
	}
	public int sub(int a,int b) {
		return a-b;
	}
	public int div(int a,int b) {
		return a/b;
	}
//	protected void setUp() throws Exception {
//		// TODO Auto-generated method stub
//		
//	}
	


}
