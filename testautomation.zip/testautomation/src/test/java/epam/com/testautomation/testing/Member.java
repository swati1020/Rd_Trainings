package epam.com.testautomation.testing;

public class Member {

}
