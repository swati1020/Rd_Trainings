package epam.com.testautomation.testing;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
    public String sendMsg() {
    	System.out.println("hello");
		return "swayi";
    }
}
