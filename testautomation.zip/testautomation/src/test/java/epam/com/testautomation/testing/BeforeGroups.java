package epam.com.testautomation.testing;

public @interface BeforeGroups {

}
