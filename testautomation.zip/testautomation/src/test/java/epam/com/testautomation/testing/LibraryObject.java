package epam.com.testautomation.testing;

public class LibraryObject extends Exception {

}
