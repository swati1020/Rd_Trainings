package epam.com.testautomation.testing;

public class Book {
	
	private int id;
	private String nameOfTheBook;
	private String authorOfTheBook;
	public Book(int i, String string, String string2) {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNameOfTheBook() {
		return nameOfTheBook;
	}
	public void setNameOfTheBook(String nameOfTheBook) {
		this.nameOfTheBook = nameOfTheBook;
	}
	public String getAuthorOfTheBook() {
		return authorOfTheBook;
	}
	public void setAuthorOfTheBook(String authorOfTheBook) {
		this.authorOfTheBook = authorOfTheBook;
	}
	

}
