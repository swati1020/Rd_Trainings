package TestAutomation.testng.exception;

public class BookDoesNotExist {

}
