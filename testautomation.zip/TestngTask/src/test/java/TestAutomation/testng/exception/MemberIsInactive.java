package TestAutomation.testng.exception;

public enum MemberIsInactive {

}
