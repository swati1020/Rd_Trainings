package TestAutomation.testng.exception;

public enum MemberStatus {

	ACTIVE,
	INACTIVE
}

