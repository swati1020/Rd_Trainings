package epam.com.TestngTask;


public class LibraryObjectNotSupported extends Exception{

	public LibraryObjectNotSupported() {
		super();
	}
	
	public LibraryObjectNotSupported(String message) {
		super(message);
	}
}

