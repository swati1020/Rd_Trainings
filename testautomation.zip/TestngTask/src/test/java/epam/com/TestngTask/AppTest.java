package epam.com.TestngTask;
import static org.testng.Assert.assertTrue;



/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @org.testng.annotations.Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
