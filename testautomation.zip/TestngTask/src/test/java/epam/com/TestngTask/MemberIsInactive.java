package epam.com.TestngTask;

public class MemberIsInactive {

}
