package epam.com.TestngTask;

public enum MemberID {

}
