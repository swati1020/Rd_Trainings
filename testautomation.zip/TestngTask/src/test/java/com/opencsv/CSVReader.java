package com.opencsv;

public enum CSVReader {
	;

	public String[] readNext() {
		// TODO Auto-generated method stub
		return null;
	}

}
